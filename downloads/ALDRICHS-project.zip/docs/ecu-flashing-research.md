# ECU 刷写调研与路线图

调研时间：2026-11。结论用于指导本项目“全平台刷写框架”的后续开发。

## 1. 原厂程序从哪来

**不从网上下载。** BMW/MINI 的原厂刷写数据（ISTA/SDP、psdzdata）是宝马的版权内容，只通过经销商授权系统分发；网上流传的都是盗版，本项目不使用。而且下载来的程序版本未必和车上的 ECU 硬件、软件号对得上，刷下去容易变砖。

**从车上读。** 正确做法是先把这辆车 ECU 里的原厂程序读出来存档。读出来的就是和这辆车 100% 匹配的原厂程序。所有正规刷写工具（开源的 VW_Flash，商业的 FoxFlash、KT200 等）都遵循“先读原厂 → 再改 → 再写”的流程，手里永远保留这辆车的原始备份。

## 2. 开源项目现状

| 项目 | 用途 | 对本项目的价值 |
| --- | --- | --- |
| [bri3d/VW_Flash](https://github.com/bri3d/VW_Flash) | 大众 Simos/MED17 的 UDS 刷写，含压缩、加密、校验和修正 | 最成熟的开源刷写范例，流程和校验和思路可以直接参考 |
| [HowIGotHere/ZephyrFlasher](https://github.com/HowIGotHere/ZephyrFlasher) | VW_Flash 的 iOS 移植 | 手机刷写的先例 |
| [dspl1236/VAGFlasher](https://github.com/dspl1236/VAGFlasher) | 开源大众 ECU 刷写（ME17 / MED9 / ME7 / EDC17），不联网不订阅 | 结构清晰，可读出到文件 |
| [variousdemeanors/tricore-bsl-engine](https://github.com/variousdemeanors/tricore-bsl-engine) | TriCore TC1767 芯片级 CAN 引导读取 / 备份 | 理论上适用于任何 TC1767 ECU；需要拆 ECU 上台架，未在 MEVD17 上实测，写入有变砖风险 |
| [matiss/motronic-checksum](https://github.com/matiss/motronic-checksum) | Bosch Motronic 校验和修正 | 校验和算法参考 |
| [pylessard/python-udsoncan](https://github.com/pylessard/python-udsoncan) | UDS（ISO 14229）完整实现 | 协议栈参考 |
| [natanaelfejes/kline](https://github.com/natanaelfejes/kline) | Rust 版 K-Line / KWP2000 | MINI 一代 K-Line 参考 |
| [RomRaider/RomRaider](https://github.com/RomRaider/RomRaider)、[LibreTuner/LibreTuner](https://github.com/LibreTuner/LibreTuner) | 开源调校，ECU 定义文件 | “用定义文件描述每种 ECU”的架构思路 |
| [zer02dev/BimmerDaten](https://github.com/zer02dev/BimmerDaten)、[radelbro/BimmerDis](https://github.com/radelbro/BimmerDis) | BMW EDIABAS / NCS 数据解析 | MINI 编码（非刷写）参考 |
| [CaringCaribou/caringcaribou](https://github.com/CaringCaribou/caringcaribou) | CAN 总线探测 | 逆向新车型时扫描 ECU 和服务 |

**MINI / BMW 没有现成的开源刷写器。** 针对 MEVD17 / MED17 读写、seed/key、校验和修正的成熟方案都是收费工具（FormulaFlash、BitBox、FoxFlash、KT200 等）。

## 3. MINI R 系列的 ECU

| 代 | 发动机 | ECU | 芯片 | 刷写难度 |
| --- | --- | --- | --- | --- |
| 一代 R50/R52/R53 | W10/W11 汽油 | Siemens EMS2000 | 较老的 MCU | 开源资料极少 |
| 二代 R55–R61 | N12/N16 汽油 | Siemens MEV17 / MEV17.2 | — | 开源资料少 |
| 二代 R55–R61 | N14/N18 汽油 | Bosch MED17.2 / MEVD17.2.2 | Infineon TriCore | 有商业工具，无开源 |
| 二代 R55–R61 | 柴油 | Bosch EDC16C34 / EDC17 | TriCore（EDC17） | 有商业工具，无开源 |

注意事项：

- 不同资料对 MEVD17.2 的芯片型号说法不一（TC1767 / TC1797 / TC1793），动手前必须拆开确认实物型号。
- 这类 ECU 往往不能只靠 OBD 口完整读出全部程序，常需要“台架读”（拆下 ECU，进 boot 模式）。
- 有的版本部分区域有写保护，需要先读出密码。
- 参考：[FormulaFlash 台架读写 MEVD17.2.3](https://formulaflash.org/formulaflash-read-write-bmw-mevd17-2-3-ecu-on-bench-successfully/)、[FoxFlash/KT200 克隆 MEDC17](https://www.obdexpress.co.uk/service/clone-bosch-medc17-with-foxflash-kt200.html)。以上均为厂商或论坛资料，未经独立验证。

## 4. “傻瓜刷写”的设计

按钮可以做到“一键”，但难的不是按钮，而是每种 ECU 的 seed/key、内存布局、校验和，以及一份经过验证的程序。框架已经把通用部分做好，各车型只需补上差异：

```
一键备份：识别 ECU → 编程会话 → seed/key 解锁 → 分块读出 → 存 .mrbk（含 VIN、标定号、SHA-256）
一键恢复：校验文件 → 核对是不是这辆车 → 检查电压 → 自动备份当前程序 → 写入 → 修正校验和 → 读回逐字节核对 → 复位
```

内置的防呆保护：

- 备份文件记录 VIN 和 SHA-256。文件损坏、换了车、换了 ECU 型号，都会拒绝恢复。
- 电压低于 12.5V 时拒绝写入。
- 写入前自动备份当前程序，写完读回逐字节比对。
- 读写过程中禁止断开连接、禁止读取仪表数据（防止和读写抢通讯）。

## 5. 路线图

1. **已完成**：通用刷写流程（`FlashRunner`）、备份文件格式（`.mrbk`）、一键备份/恢复界面、演示模式下的模拟 ECU（`DemoFlashProvider`），并有测试覆盖。
2. **下一步，二选一**：
   - **大众 MQB**：照 VW_Flash 实现第一个真·刷写模块，开源资料最全，最有可能先在真车上跑通。
   - **MINI 二代**：准备一块备用 MEVD17/MED17 ECU 和台架，确认芯片型号；先实现“只读备份”，验证 seed/key 和内存布局。
3. **再往后**：改程序（调校）。注意：修改动力程序会影响排放合规、年检和质保。

## 补充：一键解锁（seed/key）实现

已实现一个通用的 security access 引擎（`src/platform/security-access.ts`）：

- 完整的 UDS/KWP 握手（27 01 请种子 → 27 02 发密钥），处理各种否定响应：密钥错误(0x35)、超次(0x36)、需等待(0x37)、条件不满足(0x22) 等。
- 遇到“需等待”自动暂停后重试同一算法；有尝试次数上限，避免把真车 ECU 锁死。
- 密钥算法库（`src/platform/seedkey.ts`）：一键解锁按顺序逐个试。目前收录的是**通用/公开**算法族（恒等、取反、异或常量、移位、字节交换等），**不是**任何厂家的私有密钥。
- 某款 ECU 的真实算法在台架上逆出来后，作为一条新算法加进算法库即可，一键解锁立刻生效。

演示模式下有一个模拟的带 seed/key 保护的 ECU（`SimSeedKeyEcu`），用算法库里的一个算法当“私钥”，一键解锁能真实地试出它——整条引擎在演示模式就是真的在跑。

真车（尤其 MINI 二代 MEVD17）的私有算法仍需逆向，这一步没有捷径。

## 更新（2026-11）：到网上找开源解锁的结论

去 GitHub 和网络系统查了一轮：

**MINI / BMW：开源里没有,而且部分从原理上就拿不到。**
- 新款 BMW/MINI（MEVD17、MG1、MD1 这一代）用 RSA 签名,私钥锁在 ECU 自己的 bootloader 里,外部无法推导（[UnlockECU issue #8](https://github.com/jglim/UnlockECU/issues/8)、[MSS6x-Flasher](https://github.com/terraphantm/MSS6x-Flasher)）。
- 老款 ME 系列是未公开的非线性 16 位算法。
- [therudywolf/MS4X](https://github.com/therudywolf/MS4X)（BMW MS42/MS43 逆向）里没有 seed/key,只做刷写校验。
- **对 MINI 的现实意义**：备份原厂程序应走 **boot 模式 / 台架读**,直接读 flash 芯片,根本不经过 seed/key 解锁。要改程序才需要解锁,而那一步 MINI 没有开源捷径。

**开源里真实存在的解锁算法（都不是 MINI）：**
- [ludwig-v/psa-seedkey-algorithm](https://github.com/ludwig-v/psa-seedkey-algorithm)（GPL-3.0）：标致/雪铁龙/欧宝,完整算法。GPL 会传染本项目许可,未采用。
- [jglim/UnlockECU](https://github.com/jglim/UnlockECU)（MIT,463★）：主要是奔驰 + 通用算法（VolkswagenSA2、Bosch/Conti 等）,无 BMW/MINI。
- [bri3d/sa2_seed_key](https://github.com/bri3d/sa2_seed_key)（MIT）：大众/奥迪 SA2。**已移植到 `src/platform/sa2.ts` 并用它的两个官方测试向量验证通过**。

**已落地**：VAG SA2 解释器（`src/platform/sa2.ts`）。SA2 是一段每款 ECU 自带的字节码脚本,从该 ECU 的刷写数据（FRF/ODX）里取出脚本即可算 key。这是框架里第一个真实可用的解锁算法,等接入大众车型模块后,一键解锁对 VAG 就是真的。

**结论**：MINI 一键解锁无法从开源填入,只能在备用 ECU 上逆向（且新款受 RSA 限制可能逆不出可用的 key）。VAG 则已具备真实解锁能力,是先在真车上验证整条链路的最佳选择。

## 更新：奔驰 / 捷豹路虎

**奔驰（Mercedes / Daimler）：开源覆盖最好,算法已移植。**
- [jglim/UnlockECU](https://github.com/jglim/UnlockECU)（MIT）里奔驰的 seed/key 是自包含的线性算法（LCG + 异或私钥）,不像 BMW 那样 RSA 锁死。
- 已移植到 `src/platform/daimler.ts`,三个变体（standard / refG / mod）。
- ⚠️ 没有公开测试向量,只做了自洽/反推验证,未在真车核对。每台车的 K（私钥）要从该 ECU 定义数据取,或从一对已知 (seed,key) 反推（算法固有弱点）。

**捷豹路虎（JLR）：开源里基本没有。**
- 唯一相关的 [Ra3mbl/JLR-ECU-Bruteforcer](https://github.com/Ra3mbl/JLR-ECU-Bruteforcer) 只有一个 XML 配置表（各模块的安全等级、访问 DID）,**没有算法、没有代码**。
- 没有公开的 JLR seed/key 算法,只能逐 ECU 逆向。

**不做的事**：不实现通用的 security access 暴力破解工具（对任意车强行绕过解锁 = 偷车/非法改装手法）。现有“一键解锁”只试已知的公开算法并有次数上限,与暴力穷举钥匙空间是两回事。

### 各平台开源解锁对照

| 平台 | 开源解锁 | 本项目状态 |
| --- | --- | --- |
| 大众 VAG | ✅ SA2（MIT） | 已实现并用官方测试向量验证（sa2.ts） |
| 奔驰 Daimler | ✅ 线性算法（MIT） | 已移植,自洽验证,待真车核对（daimler.ts） |
| 标致/雪铁龙 PSA | ✅（GPL） | 未采用（GPL 传染许可） |
| 捷豹路虎 JLR | ❌ 仅配置表 | 无算法,需逐 ECU 逆向 |
| MINI / BMW | ❌ 私有,新款 RSA | 无,备份走 boot 模式绕过 |

## 更新：奔驰车型模块已建

`src/modules/mercedes.ts`：奔驰已是**可选车型模块**（不再是占位）。
- 两个变体：柴油（OM651/OM642/OM654/OM656）、汽油（M271/M274/M276/AMG）。
- 诊断（故障码、实时数据、VIN）走标准 OBD，真车可用。
- 解锁接入 Daimler 算法；真车需要该 ECU 的 K（私钥，可从一对 seed/key 反推）。
- 演示模式用一台“已知 K 的模拟奔驰 ECU”，一键解锁用真实的 Daimler 算法一次命中（已有测试与端到端验证）。

## 更新：捷豹路虎车型模块已建（诊断可用，解锁待逆向）

`src/modules/jlr.ts`：按车型年款分三代。
- 2014 代（AJ126/AJ133/306DT/224DT）、2017 代（Ingenium AJ200D/AJ200P）、2020 代（AJ300 直六 MHEV）。
- 诊断走标准 OBD,真车可用。
- 解锁开源没有算法；2020 代 Bosch MG1/MD1 与宝马同代,疑为 RSA 签名,从外部推不出。
- 演示模式里 JLR 的一键解锁**故意如实失败**（模拟 ECU 的私钥不在算法库内 → “需要逆向”），准确反映真实情况,不假装成功。

## 更新：大众集团（VAG）车型模块已建

`src/modules/vw.ts`：大众/奥迪/斯柯达/西雅特。
- 汽油（EA211/EA888/EA839）、柴油（EA189/EA288/EA897）两变体,含各自 ECU。
- 诊断走标准 OBD,真车可用。
- **解锁接入 SA2**（platform/sa2.ts，开源移植且用官方测试向量验证过）。这是本项目里解锁算法**唯一经过测试向量验证**的平台。
- 演示模式用一台 SA2 保护的模拟 VAG ECU（脚本用 SA2 官方测试向量 1），一键解锁用真实 SA2 一次命中。
- 真车要用:需要该 ECU 的 SA2 脚本（在它的刷写数据 FRF/ODX 里）；解锁通了之后,备份/写入/调校就能接上。VAG 是最适合先在真车上验证整条链路的平台。

## 更新：真实 UDS 刷写协议已接入大众模块

`src/platform/uds.ts` + `uds-sim.ts`:实现完整 UDS 刷写协议并接到大众模块。
- 服务:10 编程会话 / 27 SA2 解锁 / 31 擦除+校验 / 34 下载 / 36 分块传输 / 37 结束 / 35 上传读回 / 11 复位。
- `UdsFlashProvider` 是真车可用的刷写实现,按 `UdsFlashConfig`(解锁算法、地址、例程 id、块大小)参数化。
- 大众演示现在走**真实 UDS 流程**(对一台 SA2 保护的模拟 ECU),不再是内存快捷方式:一键解锁(SA2)→备份(35/36 读回)→恢复(擦除→34/36/37→31 校验→读回核对),端到端验证通过。
- 真车要用:填入该 ECU 的 SA2 脚本、内存地址/大小、擦除与校验例程 id 即可。这几项来自该车的刷写数据(FRF/ODX)。

## 更新：AI 调校顾问（有护栏）

接入 AI 调程序,但按"AI 当参谋不当手"的原则做:
- `platform/ai-tuning.ts`：AI 只在**已定义、有上下限**的参数上提建议,不碰生马力 map（没 map 定义就是瞎写,危险）。
- AI 给的每个值**代码强制钳到安全范围**,AI 超不出去；返回"从→到 + 理由",**人工逐项确认**才生效；原厂备份始终保留；**绝不自动刷写**。
- `platform/ai-client-http.ts`：支持 OpenAI 兼容 / Anthropic,key 用户自填；桌面走 Electron 主进程转发,避免 CORS。
- 编码/调校面板新增"AI 建议"区（实验）。核心护栏有测试覆盖（越界钳制、清单外忽略、JSON 解析容错）。

**没做的（诚实）**：真正的"调马力"= 改标定里的增压/喷油/点火/扭矩 map,需要每款 ECU 的 map 定义（A2L/XDF）+ 台架/测功机验证,风险最高,未实现,也不让 AI 盲改。

## 更新：数据记录（Log）能力

`src/core/logger.ts` + 「记录」页:只读采集,零风险。
- 勾选通道（转速/增压/点火/节气门等）,设采样间隔,导出 CSV（表头带单位）。
- **自动触发（自行按要求跑 log）**:设开始条件（如 节气门>90%）→ 满足才记,到设定秒数或条件消失后自动停。
- **AI 生成记录方案**:一句话（"记录一次全油门加速"）→ AI 选好通道 + 触发条件,确认后开始。AI 只能选已有通道,触发值随意但采集只读、无风险。
- 核心逻辑有测试（手动/自动触发/松开即停/CSV）。

## 更新：标定 map 定义导入（XDF）—— 真正"调马力"的地基

`src/platform/map-def.ts` + 「Map 调校」面板:
- 解析 TunerPro **XDF** 常见子集（XDFCONSTANT 标量 / XDFTABLE 表格的 z 轴 EMBEDDEDDATA + MATH 换算）。
- 从 ROM（原厂备份）按地址+位宽+公式读出物理值（增压 kPa、点火 ° 等）；可编辑标量、整表 ×% 缩放。
- 写回:只支持**线性**公式（raw=(phys-b)/a，覆盖绝大多数 map），非线性只读（不瞎写）；写入按物理范围和原始位宽双重钳制。
- 导出修改后的 ROM；刷写仍走 解锁 + UDS + 读回校验。
- 核心有测试（解析、换算、读写 round-trip、范围钳制、非线性只读）。
- 说明:XDF 的字节序/符号位约定不同文件略有差异,按常见约定解析并可覆盖,用前拿已知值核对。真正改动力 map 影响排放/年检/质保,务必台架或测功机验证。
